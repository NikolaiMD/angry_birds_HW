class Bird2 {
  constructor() {
    // BIRD INFO
    this.left = Math.floor(Math.random()*400);
    this.top = Math.floor(Math.random()*400);
    this.direction = "right";
    this.speed = 1;
  }
  render(){
    let html = `<div id="b-2" onclick="b2.die();" style="top: ${this.top}px; left: ${this.left}px;" class="bird b-2 ${this.c}"></div>`;
    let div =  document.getElementById('map');
    div.innerHTML = html;
  }
  fly(){
    setInterval(function(){
      if(b2.left>452){
        b2.direction="left";
        b2.top+= Math.floor(Math.random()*60)-30;
        b2.render();
        b2.speed= Math.floor(Math.random()*10)+1;
      }
      if(b2.left<0){
        b2.direction="right";
        b2.top+= Math.floor(Math.random()*60)-30;
        b2.render();
        b2.speed= Math.floor(Math.random()*10)+1;
      }
      if(b2.direction=="right"){
        b2.left+=b1.speed;
      }
      else{
        b2.left-=b2.speed;
      }
      let d = b2.direction == "left" ? "l" : "r";
      // b1.render();
      let div = document.getElementById('b-1');
      div.style.left = b2.left+'px';
      if(d=="l"){
        div.style.transform="scaleX(-1)";
      }else{
        div.style.transform="scaleX(1)";
      }
    }, 100);
  }
  die(){
    this.c="animated rollOut";
    this.render();
    alert("OUCH!");
    setTimeout(function(){
      b2.c="";
      b2.top= Math.floor(Math.random()*400);
      b2.left= Math.floor(Math.random()*400);
      b2.render;
    }, 2000)
  }
}
//////////////////////////////////////////////
let b2 = new Bird2;
b2.render();
b2.fly();
