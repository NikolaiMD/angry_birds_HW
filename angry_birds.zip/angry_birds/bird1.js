class Bird {
  constructor() {
    this.left = Math.floor(Math.random()*400);
    this.top = Math.floor(Math.random()*400);
    this.left_2 = Math.floor(Math.random()*400);
    this.top_2 = Math.floor(Math.random()*400);
    this.left_3 = Math.floor(Math.random()*400);
    this.top_3 = Math.floor(Math.random()*400);
    this.direction = "right";
    this.speed = 1;
  }
  render(){
    let html = `<div id="b-1" onclick="b1.die();" style="top: ${this.top}px; left: ${this.left}px;" class="bird b-1 ${this.c}"></div>
                `;
    let div = document.getElementById('map_one');
    div.innerHTML = html;
  }
  render2(){
    let html = `
                <div id="b-2" onclick="b2.die2();" style="top: ${this.top_2}px; left: ${this.left_2}px;" class="bird b-2 ${this.c_2}"></div>
                `;
    let div = document.getElementById('map_two');
    div.innerHTML = html;
  }
  render3(){
    let html = `<div id="b-3" onclick="b3.die3();" style="top: ${this.top_3}px; left: ${this.left_3}px;" class="bird b-3 ${this.c_3}"></div>`;
    let div = document.getElementById('map_three');
    div.innerHTML = html;
  }
  fly(){
    setInterval(function(){
      if(b1.left>452){
        b1.direction="left";
        b1.top+= Math.floor(Math.random()*60)-30;
        b1.render();
        b1.speed= Math.floor(Math.random()*10)+1;
      }
      if(b1.left<0){
        b1.direction="right";
        b1.top+= Math.floor(Math.random()*60)-30;
        b1.render();
        b1.speed= Math.floor(Math.random()*10)+1;
      }
      if(b1.direction=="right"){
        b1.left+=b1.speed;
      }
      else{
        b1.left-=b1.speed;
      }
      let d = b1.direction == "left" ? "l" : "r";
      let div = document.getElementById('b-1');
      div.style.left = b1.left+'px';
      if(d=="l"){
        div.style.transform="scaleX(-1)";
      }else{
        div.style.transform="scaleX(1)";
      }
    }, 50);
  }
  fly2(){
    setInterval(function(){
      if(b2.left_2>452){
        b2.direction="left";
        b2.top_2+= Math.floor(Math.random()*60)-30;
        b2.render2();
        b2.speed= Math.floor(Math.random()*10)+1;
      }
      if(b2.left_2<0){
        b2.direction="right";
        b2.top_2+= Math.floor(Math.random()*60)-30;
        b2.render2();
        b2.speed= Math.floor(Math.random()*10)+1;
      }
      if(b2.direction=="right"){
        b2.left_2+=b2.speed;
      }
      else{
        b2.left_2-=b2.speed;
      }
      let d = b2.direction == "left" ? "l" : "r";
      let div2 = document.getElementById('b-2');
      div2.style.left = b2.left_2+'px';
      if(d=="l"){
        div2.style.transform="scaleX(-1)";
      }else{
        div2.style.transform="scaleX(1)";
      }
    }, 50);
  }
  fly3(){
    setInterval(function(){
      if(b3.left_3>452){
        b3.direction="left";
        b3.top_3+= Math.floor(Math.random()*60)-30;
        b3.render3();
        b3.speed= Math.floor(Math.random()*10)+1;
      }
      if(b3.left_3<0){
        b3.direction="right";
        b3.top_3+= Math.floor(Math.random()*60)-30;
        b3.render3();
        b3.speed= Math.floor(Math.random()*10)+1;
      }
      if(b3.direction=="right"){
        b3.left_3+=b3.speed;
      }
      else{
        b3.left_3-=b3.speed;
      }
      let d = b3.direction == "left" ? "l" : "r";
      let div3 = document.getElementById('b-3');
      div3.style.left = b3.left_3+'px';
      if(d=="l"){
        div3.style.transform="scaleX(-1)";
      }else{
        div3.style.transform="scaleX(1)";
      }
    }, 50);
  }
  die(){
    this.c="animated rollOut";
    this.render();
    // alert("OUCH!");
    setTimeout(function(){
      b1.c="";
      b1.top= Math.floor(Math.random()*400);
      b1.left= Math.floor(Math.random()*400);
      b1.render();
    }, 2000)
  }
  die2(){
    this.c_2="animated rollOut";
    this.render2();
    // alert("OUCH!");
    setTimeout(function(){
      b2.c_2="";
      b2.top_2= Math.floor(Math.random()*400);
      b2.left_2= Math.floor(Math.random()*400);
      b2.render2();
    }, 2000)
  }
  die3(){
    this.c_3="animated rollOut";
    this.render3();
    // alert("OUCH!");
    setTimeout(function(){
      b3.c_3="";
      b3.top_3= Math.floor(Math.random()*400);
      b3.left_3= Math.floor(Math.random()*400);
      b3.render3();
    }, 2000)
  }
}
let b1 = new Bird;
b1.render();
b1.fly();
// b1.die();
let b2 = new Bird;
b2.render2();
b2.fly2();
// b2.die2();
let b3 = new Bird;
b3.render3();
b3.fly3();
// b3.die3();
